"use strict";
exports.__esModule = true;
exports.persons = void 0;
var persons = /** @class */ (function () {
    function persons() {
    }
    return persons;
}());
exports.persons = persons;
