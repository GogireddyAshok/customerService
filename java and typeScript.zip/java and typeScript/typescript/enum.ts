enum DaysOfTheWeek{
    SUN=100,MON,TUES,WED,THU,FRI,SAT
}

let day: DaysOfTheWeek;
day=DaysOfTheWeek.MON;

if (day==DaysOfTheWeek.MON) {
    console.log("let's start")
}