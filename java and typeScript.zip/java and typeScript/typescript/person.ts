export class persons{
    firstname: string;
    lastname: string;
}