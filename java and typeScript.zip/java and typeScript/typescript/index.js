import {person} from './class';

let foo = new person();
foo.firstname='ashok';
foo.lastname='gogireddy';
console.log(foo);